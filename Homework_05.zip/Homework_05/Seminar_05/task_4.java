package Seminar_05;

public class task_4 {

  public static void printMatrix(int s[][]) {
    for (int i = 0; i < s.length; i++) {
      System.out.print("\n\t");
      for (int j = 0; j < s.length; j++) {
        System.out.print(s[j][i] + "  ");
      }
    }
    System.out.println();
  }

  public static void getPlace(int s[][], int q, int[] k) {

    boolean fl = true;
    for (int i = 0; i < s.length; i++) {
      for (int j = 0; j < s.length; j++) {
        if (fl) {
          if (s[i][j] == 0) {
            s[i][j] = q;
            k[0] = i;
            k[1] = j;
            fl = false;
            k[2] += 1;
          }
        }
      }
    }
  }

  public static void completion(int[][] s, int[] k) {
    int a = k[0];
    int b = k[1];
    // право
    while (a <= 7) {
      if (s[a][b] == 0) {
        s[a][b] = 1;
      }
      a++;
    }
    // влево
    a = k[0];
    while (a >= 0) {
      if (s[a][b] == 0) {
        s[a][b] = 1;
      }
      a--;
    }

    // вниз
    a = k[0];
    b = k[1];
    while (b <= 7) {
      if (s[a][b] == 0) {
        s[a][b] = 1;
      }
      b++;
    }

    // вверх
    b = k[1];
    while (b >= 0) {
      if (s[a][b] == 0) {
        s[a][b] = 1;
      }
      b--;
    }

    // диагональ палочка влево
    a = k[0];
    b = k[1];
    while (a >= 0 && b >= 0) {
      if (s[a][b] == 0) {
        s[a][b] = 1;
      }
      a--;
      b--;
    }
    a++;
    b++;
    while (a <= 7 && b <= 7) {
      if (s[a][b] == 0) {
        s[a][b] = 1;
      }
      a++;
      b++;
    }
    // диагональ палочка вправо
    a = k[0]; // 2
    b = k[1]; // 3 .. 2 3 1 4 0 5
    while (a >= 0 && b <= 7) {
      if (s[a][b] == 0) {
        s[a][b] = 1;
      }
      a--;
      b++;
    }
    a++;
    b--;
    while (a <= 7 && b >= 0) {
      if (s[a][b] == 0) {
        s[a][b] = 1;
      }
      a++;
      b--;
    }
  }

  public static void main(String[] args) {
    // На шахматной доске расставить 8 ферзей так, чтобы они не били друг друга
    System.out.print("\033[H\033[2J"); // очистка консоли
    System.out.println("\nЗ А Д А Ч А  4\n");
    System.out.println("- -- На шахматной доске расставить 8 ферзей -- -");
    System.out.print("      - -- Ферзь в виде '2' -- -");

    int[][] s = new int[8][8];
    int[] k = new int[3];

    int a = 2;

    // int point = 1;
    // s[1][point] = a;
    // k[2] = 1;
    // completion(s, k);
    // // s[1][6] = a;
    // // completion(s, k);

    System.out.println();
    for (int i = 0; i < 7; i++) {
      getPlace(s, a, k);
      completion(s, k);
      // printMatrix(s);
    }

    printMatrix(s);

    // System.out.printf(" \n(%d, %d)", k[0], k[1]);

    System.out.println();
    // k[0] = 7;
    // k[1] = 7;
    System.out.println("Число ферзей на доске -> " + k[2] + "\n");
    System.out.println("P.s. Пока удалось получить только -> " + k[2] + "\n");

  }
}
