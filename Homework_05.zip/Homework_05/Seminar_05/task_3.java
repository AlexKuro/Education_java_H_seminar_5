package Seminar_05;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class task_3 {

  public static void fillarray(ArrayList<Integer> array, int size) {
    Random random = new Random();
    for (int i = 0; i < size; i++) {
      array.add(random.nextInt(99));
    }
  }

  public static void printarray(ArrayList<Integer> array) {
    Iterator<Integer> itar = array.iterator();
    while (itar.hasNext()) {
      System.out.print(itar.next() + " ");
    }
  }

  private static void siftDown(ArrayList<Integer> array, int root, int bottom) {
    int maxChild = 0;
    boolean done = false;
    while ((root * 2 <= bottom) && (!done)) {
      if (root * 2 == bottom) {
        maxChild = root * 2;
      } else if (array.get(root * 2) > array.get(root * 2 + 1)) {
        maxChild = root * 2;
      } else {
        maxChild = root * 2 + 1;
      }
      if (array.get(root) < array.get(maxChild)) {
        int temp = array.get(root);
        array.set(root, array.get(maxChild));
        array.set(maxChild, temp);
        root = maxChild;
      } else {
        done = true;
      }
    }
  }

  public static void heapSort(ArrayList<Integer> array, int size) {
    for (int i = (size / 2); i >= 0; i--) {
      siftDown(array, i, size - 1);
    }
    for (int i = size - 1; i >= 1; i--) {
      int temp = array.get(0);
      array.set(0, array.get(i));
      array.set(i, temp);
      siftDown(array, 0, i - 1);
    }
  }

  public static void main(String[] args) {
    // task_3 - Реализовать алгоритм пирамидальной сортировки (HeapSort).
    System.out.print("\033[H\033[2J"); // очистка консоли
    int size = 12;
    System.out.println("\nЗ А Д А Ч А  3\n");
    System.out.println("- -- Пирамидальная сортировка -- -");
    ArrayList<Integer> array = new ArrayList<>();
    fillarray(array, size);
    System.out.print("Массив заполнен - - ----> ");
    printarray(array);
    System.out.print("\nОтсортированный массив -> ");
    heapSort(array, size);
    printarray(array);
    System.out.print("\n\n");

  }
}